const mysql = require('mysql2/promise');
const fs = require('fs');

async function initDB() {
    try {
        const connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: 'root',
            multipleStatements: true
        });

        const sql = fs.readFileSync('database.sql', 'utf8');
        
        console.log("Executing database schema...");
        await connection.query(sql);
        console.log("Database and tables created successfully.");
        
        await connection.end();
    } catch (error) {
        console.error("Error setting up the database:", error);
    }
}

initDB();
