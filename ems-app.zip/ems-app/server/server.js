const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public'))); // Serve static frontend files

// --- Authentication API ---
app.post('/api/login', async (req, res) => {
    const { emp_id } = req.body;
    try {
        const [rows] = await db.query('SELECT * FROM employees WHERE emp_id = ?', [emp_id]);
        if (rows.length > 0) {
            res.json({ success: true, user: rows[0] });
        } else {
            res.status(401).json({ success: false, message: 'Invalid Employee ID' });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- Employee APIs (Admin Only usually, but let's keep it simple for now) ---
app.get('/api/employees', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM employees WHERE role = "employee"');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/employees', async (req, res) => {
    const { name, phone, birth_year } = req.body;
    // Generate unique ID: first 3 digits of phone + year of birth
    const phoneStr = String(phone);
    const emp_id = `${phoneStr.substring(0, 3)}${birth_year}`;

    try {
        const [result] = await db.query(
            'INSERT INTO employees (emp_id, name, phone, birth_year) VALUES (?, ?, ?, ?)',
            [emp_id, name, phone, birth_year]
        );
        res.json({ success: true, emp_id: emp_id, message: 'Employee added successfully' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            res.status(400).json({ error: 'Employee ID already exists (duplicate phone/birth year)' });
        } else {
            res.status(500).json({ error: err.message });
        }
    }
});

app.delete('/api/employees/:emp_id', async (req, res) => {
    const { emp_id } = req.params;
    try {
        await db.query('DELETE FROM employees WHERE emp_id = ?', [emp_id]);
        res.json({ success: true, message: 'Employee removed' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- Attendance APIs ---
app.get('/api/attendance', async (req, res) => {
    // Optional filter by emp_id or date
    const { emp_id, date } = req.query;
    let query = `
        SELECT a.*, e.name 
        FROM attendance a 
        JOIN employees e ON a.emp_id = e.emp_id
        WHERE 1=1
    `;
    const params = [];

    if (emp_id) {
        query += ' AND a.emp_id = ?';
        params.push(emp_id);
    }
    if (date) {
        query += ' AND a.date = ?';
        params.push(date);
    }

    try {
        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/attendance', async (req, res) => {
    const { emp_id, date, status } = req.body; // status: 'present' or 'absent'
    
    try {
        // Upsert logic (Insert or Update if exists)
        const [result] = await db.query(
            `INSERT INTO attendance (emp_id, date, status) 
             VALUES (?, ?, ?) 
             ON DUPLICATE KEY UPDATE status = VALUES(status)`,
            [emp_id, date, status]
        );
        res.json({ success: true, message: `Attendance marked as ${status}` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/attendance', async (req, res) => {
    const { emp_id, date } = req.body;
    try {
        await db.query('DELETE FROM attendance WHERE emp_id = ? AND date = ?', [emp_id, date]);
        res.json({ success: true, message: 'Attendance revoked' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- Tasks APIs ---
app.get('/api/tasks', async (req, res) => {
    const { emp_id } = req.query;
    let query = `
        SELECT t.*, e.name as assigned_to_name, a.name as assigned_by_name
        FROM tasks t
        JOIN employees e ON t.assigned_to = e.emp_id
        JOIN employees a ON t.assigned_by = a.emp_id
        WHERE 1=1
    `;
    const params = [];
    if (emp_id) {
        query += ' AND t.assigned_to = ?';
        params.push(emp_id);
    }
    query += ' ORDER BY t.created_at DESC';
    
    try {
        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/tasks', async (req, res) => {
    const { title, description, assigned_to, assigned_by } = req.body;
    try {
        await db.query(
            'INSERT INTO tasks (title, description, assigned_to, assigned_by) VALUES (?, ?, ?, ?)',
            [title, description, assigned_to, assigned_by]
        );
        res.json({ success: true, message: 'Task assigned successfully' });
    } catch (err) {
        if (err.code === 'ER_NO_REFERENCED_ROW_2') {
            res.status(400).json({ error: 'Employee ID does not exist' });
        } else {
            res.status(500).json({ error: err.message });
        }
    }
});

app.put('/api/tasks/:id/status', async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
        await db.query('UPDATE tasks SET status = ? WHERE id = ?', [status, id]);
        res.json({ success: true, message: 'Task status updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
