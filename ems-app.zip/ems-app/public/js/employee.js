window.Employee = {
    user: null,

    init: function(userData) {
        this.user = userData;
        
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        document.getElementById('current-date-display').textContent = today;
        
        this.loadTasks();
        this.bindEvents();
    },

    handleNav: function(targetId) {
        if (targetId === 'emp-dashboard') this.loadTasks();
    },

    bindEvents: function() {
        const btnMarkAtt = document.getElementById('btn-mark-self-att');
        if (btnMarkAtt) {
            btnMarkAtt.addEventListener('click', async () => {
                // Get today's date in YYYY-MM-DD format based on local time
                const today = new Date();
                const offset = today.getTimezoneOffset() * 60000;
                const localDate = (new Date(today - offset)).toISOString().split('T')[0];

                try {
                    const res = await apiRequest('/attendance', {
                        method: 'POST',
                        body: JSON.stringify({
                            emp_id: this.user.emp_id,
                            date: localDate,
                            status: 'present'
                        })
                    });
                    if (res.success) {
                        showToast("Your attendance has been marked for today!");
                        btnMarkAtt.disabled = true;
                        btnMarkAtt.textContent = "Attendance Marked";
                        btnMarkAtt.classList.remove('btn-primary');
                        btnMarkAtt.classList.add('btn-secondary');
                    }
                } catch(e) {}
            });
        }
    },

    loadTasks: async function() {
        try {
            const tasks = await apiRequest(`/tasks?emp_id=${this.user.emp_id}`);
            const grid = document.getElementById('emp-task-grid');
            grid.innerHTML = '';
            
            if(tasks.length === 0) {
                grid.innerHTML = '<p class="text-muted">You have no assigned tasks.</p>';
                return;
            }

            tasks.forEach(task => {
                const card = document.createElement('div');
                card.className = 'task-card glass-panel';
                card.innerHTML = `
                    <h3>${task.title}</h3>
                    <p>${task.description || 'No description provided.'}</p>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                        <span class="badge ${task.status === 'completed' ? 'completed' : 'pending'}">${task.status}</span>
                        ${task.status === 'pending' ? `<button class="btn btn-sm btn-primary" onclick="Employee.markTaskComplete(${task.id})">Mark Done</button>` : ''}
                    </div>
                    <p class="text-sm text-muted mt-2">Assigned by: ${task.assigned_by_name}</p>
                `;
                grid.appendChild(card);
            });
        } catch(e) {}
    },

    markTaskComplete: async function(taskId) {
        try {
            const res = await apiRequest(`/tasks/${taskId}/status`, {
                method: 'PUT',
                body: JSON.stringify({ status: 'completed' })
            });
            if (res.success) {
                showToast("Task marked as completed!");
                this.loadTasks();
            }
        } catch(e) {}
    }
};
