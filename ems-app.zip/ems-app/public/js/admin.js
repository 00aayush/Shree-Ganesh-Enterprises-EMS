window.Admin = {
    init: function() {
        this.loadDashboard();
        this.bindEvents();
    },

    handleNav: function(targetId) {
        if (targetId === 'admin-dashboard') this.loadDashboard();
        if (targetId === 'admin-attendance') this.loadAttendance();
        if (targetId === 'admin-tasks') this.loadTasks();
    },

    bindEvents: function() {
        // Add Employee Form
        const formAddEmp = document.getElementById('form-add-emp');
        if(formAddEmp) {
            formAddEmp.addEventListener('submit', async (e) => {
                e.preventDefault();
                const name = document.getElementById('emp-name').value;
                const phone = document.getElementById('emp-phone').value;
                const birth_year = document.getElementById('emp-birth').value;

                try {
                    const res = await apiRequest('/employees', {
                        method: 'POST',
                        body: JSON.stringify({ name, phone, birth_year })
                    });
                    if (res.success) {
                        showToast(res.message);
                        formAddEmp.reset();
                        document.getElementById('add-emp-result').textContent = `Success! New Employee ID is: ${res.emp_id}`;
                        document.getElementById('add-emp-result').classList.remove('hidden');
                        this.loadDashboard(); // refresh list behind the scenes
                    }
                } catch (e) {
                    document.getElementById('add-emp-result').classList.add('hidden');
                }
            });
        }

        // Attendance Management Form
        const formMarkAtt = document.getElementById('form-mark-attendance');
        if(formMarkAtt) {
            formMarkAtt.addEventListener('submit', async (e) => {
                e.preventDefault();
                const emp_id = document.getElementById('att-emp-id').value;
                const date = document.getElementById('att-date').value;
                const status = document.getElementById('att-status').value;
                
                try {
                    const res = await apiRequest('/attendance', {
                        method: 'POST',
                        body: JSON.stringify({ emp_id, date, status })
                    });
                    if (res.success) {
                        showToast(res.message);
                        this.loadAttendance();
                    }
                } catch (e) { }
            });
        }

        const btnRevokeAtt = document.getElementById('btn-revoke-att');
        if(btnRevokeAtt) {
            btnRevokeAtt.addEventListener('click', async () => {
                const emp_id = document.getElementById('att-emp-id').value;
                const date = document.getElementById('att-date').value;
                if(!emp_id || !date) return showToast('Employee ID and Date required for revoke', true);
                
                try {
                    const res = await apiRequest('/attendance', {
                        method: 'DELETE',
                        body: JSON.stringify({ emp_id, date })
                    });
                    if (res.success) {
                        showToast(res.message);
                        this.loadAttendance();
                    }
                } catch (e) {}
            });
        }

        const btnFilterAtt = document.getElementById('btn-filter-att');
        if (btnFilterAtt) {
            btnFilterAtt.addEventListener('click', () => {
                const date = document.getElementById('filter-att-date').value;
                this.loadAttendance(date);
            });
        }

        // Task Assignment Form
        const formAssignTask = document.getElementById('form-assign-task');
        if(formAssignTask) {
            formAssignTask.addEventListener('submit', async (e) => {
                e.preventDefault();
                const assigned_to = document.getElementById('task-emp-id').value;
                const title = document.getElementById('task-title').value;
                const description = document.getElementById('task-desc').value;
                const user = JSON.parse(localStorage.getItem('currentUser'));

                try {
                    const res = await apiRequest('/tasks', {
                        method: 'POST',
                        body: JSON.stringify({ title, description, assigned_to, assigned_by: user.emp_id })
                    });
                    if (res.success) {
                        showToast(res.message);
                        formAssignTask.reset();
                        this.loadTasks();
                    }
                } catch (e) {}
            });
        }
    },

    loadDashboard: async function() {
        try {
            const employees = await apiRequest('/employees');
            document.getElementById('stat-total-emp').textContent = employees.length;
            
            const tbody = document.getElementById('admin-emp-list');
            const taskEmpSelect = document.getElementById('task-emp-id');
            const attEmpSelect = document.getElementById('att-emp-id');

            tbody.innerHTML = '';
            
            if (taskEmpSelect) taskEmpSelect.innerHTML = '<option value="" disabled selected>Select an employee</option>';
            if (attEmpSelect) attEmpSelect.innerHTML = '<option value="" disabled selected>Select an employee</option>';

            employees.forEach(emp => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${emp.emp_id}</td>
                    <td>${emp.name}</td>
                    <td>${emp.phone}</td>
                    <td>${emp.birth_year}</td>
                    <td><button class="btn btn-sm btn-danger" onclick="Admin.removeEmployee('${emp.emp_id}')">Remove</button></td>
                `;
                tbody.appendChild(tr);

                const option = document.createElement('option');
                option.value = emp.emp_id;
                option.textContent = `${emp.name} (${emp.emp_id})`;
                
                if (taskEmpSelect) taskEmpSelect.appendChild(option.cloneNode(true));
                if (attEmpSelect) attEmpSelect.appendChild(option);
            });
        } catch(e) {}
    },

    removeEmployee: async function(emp_id) {
        if(!confirm(`Are you sure you want to remove employee ${emp_id}?`)) return;
        try {
            const res = await apiRequest(`/employees/${emp_id}`, { method: 'DELETE' });
            if(res.success) {
                showToast(res.message);
                this.loadDashboard();
            }
        } catch(e) {}
    },

    loadAttendance: async function(dateFilter = '') {
        try {
            let url = '/attendance';
            if(dateFilter) url += `?date=${dateFilter}`;
            
            const records = await apiRequest(url);
            const tbody = document.getElementById('admin-att-list');
            tbody.innerHTML = '';
            records.forEach(rec => {
                const tr = document.createElement('tr');
                const dateStr = new Date(rec.date).toISOString().split('T')[0];
                tr.innerHTML = `
                    <td>${rec.name}</td>
                    <td>${rec.emp_id}</td>
                    <td>${dateStr}</td>
                    <td><span class="badge ${rec.status === 'present' ? 'completed' : 'pending'}">${rec.status}</span></td>
                `;
                tbody.appendChild(tr);
            });
        } catch(e) {}
    },

    loadTasks: async function() {
        try {
            const tasks = await apiRequest('/tasks');
            const tbody = document.getElementById('admin-task-list');
            tbody.innerHTML = '';
            tasks.forEach(task => {
                const tr = document.createElement('tr');
                const dateStr = new Date(task.created_at).toLocaleString();
                tr.innerHTML = `
                    <td>${task.title}</td>
                    <td>${task.assigned_to_name} (${task.assigned_to})</td>
                    <td><span class="badge ${task.status === 'completed' ? 'completed' : 'pending'}">${task.status}</span></td>
                    <td>${dateStr}</td>
                `;
                tbody.appendChild(tr);
            });
        } catch(e) {}
    }
};
