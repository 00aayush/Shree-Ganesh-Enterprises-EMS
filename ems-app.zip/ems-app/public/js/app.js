const API_BASE = 'http://localhost:3000/api';

// Utility: Show Toast Notification
function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.style.borderLeftColor = isError ? 'var(--danger-accent)' : 'var(--success-accent)';
    toast.classList.remove('hidden');
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}

// Utility: API Request wrapper
async function apiRequest(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            headers: { 'Content-Type': 'application/json' },
            ...options
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || data.message || 'API request failed');
        return data;
    } catch (error) {
        showToast(error.message, true);
        throw error;
    }
}

// View Management
function switchView(viewId) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById(viewId).classList.add('active');
}

// Navigation Management (Sidebar tabs)
function setupNavigation() {
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            // Remove active from all links in the same nav
            e.target.closest('.nav-links').querySelectorAll('a').forEach(a => a.classList.remove('active'));
            e.target.classList.add('active');
            
            // Hide all sections in the current view
            const viewContainer = e.target.closest('.dashboard-container');
            viewContainer.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active'));
            
            // Show target section
            const targetId = e.target.getAttribute('data-target');
            document.getElementById(targetId).classList.add('active');
            
            // Trigger specific data loads if needed
            if(window.Admin && window.Admin.handleNav) window.Admin.handleNav(targetId);
            if(window.Employee && window.Employee.handleNav) window.Employee.handleNav(targetId);
        });
    });
}

// Authentication
const LoginForm = document.getElementById('login-form');
const LogoutBtns = document.querySelectorAll('.logout-btn');

if (LoginForm) {
    LoginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const empId = document.getElementById('login-emp-id').value.trim();
        if (!empId) return;

        try {
            const data = await apiRequest('/login', {
                method: 'POST',
                body: JSON.stringify({ emp_id: empId })
            });

            if (data.success) {
                const user = data.user;
                localStorage.setItem('currentUser', JSON.stringify(user));
                showToast(`Welcome, ${user.name}`);
                routeUser(user);
            }
        } catch (error) {
            // Toast handled in apiRequest
        }
    });
}

LogoutBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        localStorage.removeItem('currentUser');
        switchView('login-view');
        document.getElementById('login-form').reset();
    });
});

function routeUser(user) {
    if (user.role === 'admin') {
        document.getElementById('admin-user-name').textContent = `Welcome, ${user.name}`;
        switchView('admin-view');
        if(window.Admin) window.Admin.init();
    } else {
        document.getElementById('emp-user-name').textContent = `Welcome, ${user.name}`;
        switchView('employee-view');
        if(window.Employee) window.Employee.init(user);
    }
}

// App Initialization
document.addEventListener('DOMContentLoaded', () => {
    setupNavigation();
    
    // Check if already logged in
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
        routeUser(JSON.parse(storedUser));
    } else {
        switchView('login-view');
    }
});
