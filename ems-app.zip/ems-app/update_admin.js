const mysql = require('mysql2/promise');

async function updateAdmin() {
    try {
        const connection = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: 'root',
            database: 'ems_db'
        });

        // Update the admin user. We know the old ID is 9991990
        // But what if it's already updated or doesn't exist?
        // Let's just do an INSERT ON DUPLICATE KEY UPDATE or DELETE old and INSERT new.
        
        await connection.query("DELETE FROM employees WHERE role = 'admin'");
        await connection.query(
            "INSERT INTO employees (emp_id, name, phone, birth_year, role) VALUES ('880096', 'Ujjwala upadhyay', '8800572097', 1996, 'admin')"
        );
        
        console.log("Admin details updated successfully in the database.");
        await connection.end();
    } catch (error) {
        console.error("Error updating admin:", error);
    }
}

updateAdmin();
